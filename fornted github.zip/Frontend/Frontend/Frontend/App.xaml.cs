﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Aplicacion_Ejemplo
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
